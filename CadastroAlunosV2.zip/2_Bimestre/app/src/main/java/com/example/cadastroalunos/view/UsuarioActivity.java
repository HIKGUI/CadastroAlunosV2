package com.example.cadastroalunos.view;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cadastroalunos.R;
import com.example.cadastroalunos.adapter.UsuarioListAdapter;
import com.example.cadastroalunos.controller.UsuarioController;
import com.example.cadastroalunos.model.Usuario;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class UsuarioActivity extends AppCompatActivity {

    private FloatingActionButton btAddUsuario;
    private RecyclerView rvUsuario;
    private UsuarioController controller;
    private AlertDialog dialog;
    private View viewCadastro;
    private EditText edCpf, edNomeUs, edDataNasc, edSenha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_usuario);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        controller = new UsuarioController(this);
        rvUsuario = findViewById(R.id.rvUsuarios);
        btAddUsuario = findViewById(R.id.btAddUsuarios);
        btAddUsuario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirCadastro();
            }
        });

        atualizarListaUsuarios();

    }

    private void atualizarListaUsuarios(){
        ArrayList<Usuario> listaUsuarios =
                controller.retornarTodosUsuarios();

        UsuarioListAdapter adapter =
                new UsuarioListAdapter(listaUsuarios, this);

        rvUsuario.setLayoutManager(new LinearLayoutManager(this));
        rvUsuario.setAdapter(adapter);
    }

    private void abrirCadastro(){
        //Carregar o xml do layout do cadastro
        viewCadastro = getLayoutInflater()
                .inflate(R.layout.dialog_cadastro_usuario, null);

        edCpf = viewCadastro.findViewById(R.id.edCpf);
        edNomeUs = viewCadastro.findViewById(R.id.edNomeUs);
        edDataNasc = viewCadastro.findViewById(R.id.edDataNasc);
        edSenha = viewCadastro.findViewById(R.id.edSenha);

        //Carregando o popup
        final AlertDialog.Builder builder =
                new AlertDialog.Builder(this);

        builder.setTitle("CADASTRO DE USUARIOS"); //setando o titulo da tela
        builder.setView(viewCadastro); //setando o layout carregado
        builder.setCancelable(false);//não deixa o popup fechar ao clicar fora

        //Adicionando o botão cancelar, que fechará o dialog
        builder.setNegativeButton("CANCELAR", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialog.dismiss();
            }
        });

        //Adicionando o botão salvar
        //nesse ponto nào vamos adicionar o método
        //onclick, pois é necessário que os EditTexts
        // da tela estejam criados, e nesse momento
        //não estão criados
        builder.setPositiveButton("SALVAR", null);

        //Cria o dialog com o layout e os campos carrgados
        dialog = builder.create();

        //Após carregar o dialog precisamos adicionar
        // o método onClickListener no no botão SALVAR
        // agora os EditTexts estão criados em memória
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                Button bt = dialog.getButton(DialogInterface.BUTTON_POSITIVE);
                bt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        salvarDados();
                    }
                });
            }
        });

        //Exibe o dialog na tela
        dialog.show();

    }

    private void salvarDados(){
        //Envia os dados de CODIGO DO EQUIPAMENTO, nome, MARCA, DATA FABR
        //para gravar o EQUIP, validando
        //os campos e se existe o EQUIP cadastrado
        String retorno = controller
                .salvarUsuarios(edCpf.getText().toString(),
                        edNomeUs.getText().toString(),
                        edDataNasc.getText().toString(),
                        edSenha.getText().toString());

        //Informa o erro caso no campo CODIGO EQUIP
        // tenha problema
        //com o CODIGO DO EQUIPAMENTO
        if(retorno.contains("CPF")){
            edCpf.setError(retorno);
            edCpf.requestFocus();
            return;
        }

        //Informa o erro no campo Nome
        // caso tenha algum problema com
        //nome do Equipamento
        if(retorno.contains("NOME")){
            edNomeUs.setError(retorno);
            edNomeUs.requestFocus();
            return;
        }

        //Informa o erro no campo Nome
        // caso tenha algum problema com
        //marca do equipamento
        if(retorno.contains("DATANASC")){
            edDataNasc.setError(retorno);
            edDataNasc.requestFocus();
            return;
        }

        //Informa o erro no campo Nome
        // caso tenha algum problema com
        //data fabricação do equipamento
        if(retorno.contains("SENHA")){
            edSenha.setError(retorno);
            edSenha.requestFocus();
            return;
        }

        //Ao gravar o equipamento atualiza a lista
        //e fecha o dialog
        if(retorno.contains("sucesso")){
            atualizarListaUsuarios();
            dialog.dismiss();

            Intent intent =
                    new Intent(UsuarioActivity.this,
                            LoginActivity.class);

            startActivity(intent);
        }

        //Exibe mensagem
        Toast.makeText(this,
                retorno,
                Toast.LENGTH_LONG).show();
    }








}