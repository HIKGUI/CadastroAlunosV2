package com.example.cadastroalunos.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.cadastroalunos.helper.SQLiteDataHelper;
import com.example.cadastroalunos.model.Equip;

import java.util.ArrayList;

public class EquipDao implements IGenericDao<Equip>{

    //Variável responsável por abri a conexão com a BD
    private SQLiteOpenHelper openHelper;

    //Base de Dados
    private SQLiteDatabase baseDados;

    //nome das colunas da tabela
    private String[]colunas = {"COD_EQUIP","NOME", "MARCA", "DTFABR", "ESTADO", "CPFFK"};

    //Nome da tabela
    private String tabela = "EQUIPAMENTOS";

    //Contexto
    private Context context;

    private static EquipDao instancia;

    public static EquipDao getInstance(Context context){
        if(instancia == null) {
            instancia = new EquipDao(context);
        }
        return instancia;
    }

    private EquipDao(Context context) {
        this.context = context;

        // Abrir a conexão com a base de dados usando o construtor simplificado
        openHelper = new SQLiteDataHelper(this.context);
        baseDados = openHelper.getWritableDatabase();

    }


    /**
     * Método para inserir dados na tabela Equipamento
     * @param obj Equipamento
     * @return a linha que foi inserido o registro
     */
    @Override
    public long insert(Equip obj) {
        try{
            ContentValues valores = new ContentValues();
            valores.put(colunas[0], obj.getCodEquip());
            valores.put(colunas[1], obj.getNome());
            valores.put(colunas[2], obj.getMarca());
            valores.put(colunas[3], obj.getDtfabr());
            valores.put(colunas[4], "N");
            valores.put(colunas[5], obj.getCpffk());

            return baseDados.insert(tabela, null, valores);

        }catch (SQLException ex){
            Log.e("UNIPAR",
                    "ERRO: EquipamentoDao.insert() "+
                    ex.getMessage());
        }

        return 0;
    }

    /**
     * Atualizar registro na tabela Equipemento
     * @param obj Equipamento
     * @return
     */
    @Override
    public long update(Equip obj) {
        try{
            ContentValues valores = new ContentValues();
            valores.put(colunas[1], obj.getNome());

            String[]identificador =
                    {String.valueOf(obj.getCodEquip())};

            return baseDados.update(tabela,
                    valores,
                    colunas[0]+"= ?",
                    identificador);

        }catch (SQLException ex){
            Log.e("UNIPAR",
                    "ERRO: EquipamentoDao.update() "+
                            ex.getMessage());
        }
        return 0;
    }

    @Override
    public long delete(Equip obj) {
        try{
            String[]identificador =
                    {String.valueOf(obj.getCodEquip())};

            return baseDados.delete(tabela,
                    colunas[0]+" = ?",
                    identificador);

        }catch (SQLException ex){
            Log.e("UNIPAR",
                    "ERRO: EquipamentoDao.delete() "+
                            ex.getMessage());
        }
        return 0;
    }



    @Override
    public ArrayList<Equip> getAll() {
        ArrayList lista = new ArrayList<>();
        try{

            Cursor cursor = baseDados.query(tabela,
                    colunas, null, null,
                    null, null, colunas[0]);

            while(cursor.moveToNext()){
                Equip equipamentos = new Equip();
                equipamentos.setCodEquip(cursor.getInt(0));
                equipamentos.setNome(cursor.getString(1));
                equipamentos.setMarca(cursor.getString(2));
                equipamentos.setDtfabr(cursor.getString(3));
                equipamentos.setEstado(cursor.getString(4));
                equipamentos.setCpffk(cursor.getInt(5));


                lista.add(equipamentos);
            }

            cursor.close();
            return lista;

        }catch (SQLException ex){
            Log.e("UNIPAR",
                    "ERRO: EquipDao.getAll() "+
                            ex.getMessage());
        }

        return null;
    }

    @Override
    public Equip getById(int id) {
        try{
            String[]identificador =
                    {String.valueOf(id)};

            Cursor cursor = baseDados.query(tabela,
                    colunas, colunas[0]+" = ?",
                    identificador,
                    null, null, null);

            if(cursor.moveToFirst()){
                Equip equipamentos = new Equip();
                equipamentos.setCodEquip(cursor.getInt(0));
                equipamentos.setNome(cursor.getString(1));
                equipamentos.setMarca(cursor.getString(2));
                equipamentos.setDtfabr(cursor.getString(3));
                equipamentos.setEstado(cursor.getString(4));
                equipamentos.setCpffk(cursor.getInt(5));


                cursor.close();
                return equipamentos;
            }
        }catch (SQLException ex){
            Log.e("UNIPAR",
                    "ERRO: EquipDao.getById() "+
                            ex.getMessage());
        }
        return null;
    }



//alterar estado
    /**
     * Atualiza o estado de um equipamento na tabela.
     * @param codEquip Código do equipamento.
     * @param novoEstado Novo valor para o campo "estado".
     * @return Número de linhas afetadas.
     */
    public long updateEstado(int codEquip, String novoEstado) {
        try {
            ContentValues valores = new ContentValues();
            valores.put("ESTADO", novoEstado);

            String[] identificador = {String.valueOf(codEquip)};

            return baseDados.update(tabela, valores, "COD_EQUIP = ?", identificador);
        } catch (SQLException ex) {
            Log.e("UNIPAR", "ERRO: EquipDao.updateEstado() " + ex.getMessage());
        }
        return 0;
    }





}
