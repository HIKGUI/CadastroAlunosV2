package com.example.cadastroalunos.controller;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.example.cadastroalunos.dao.EquipDao;
import com.example.cadastroalunos.model.Equip;

import java.util.ArrayList;

public class EquipController {

    private Context context;

    public EquipController(Context context) {
        this.context = context;
    }

    public String salvarEquipamento(String codequip, String nome, String marca, String dtfabr){
        try{
            if(TextUtils.isEmpty(codequip)){
                return "Informe o Codigo do Equipamento";
            }
            if(TextUtils.isEmpty(nome)){
                return "Informe o NOME do Equipamento";
            }
            if(TextUtils.isEmpty(nome)){
                return "Informe a Marca do Equipamento";
            }
            if(TextUtils.isEmpty(nome)){
                return "Informe a Data de Fabricação do Equipamento";
            }

            //Verifica se existe um equipamento cadastrado com
            // o COD EQUIPO informado
            Equip equipamentos = EquipDao
                    .getInstance(context)
                    .getById(Integer.parseInt(codequip));

            if(equipamentos != null){
                return "O Codiogo do Equipamento ("+codequip+") já está cadastrado.";
            }else{
                equipamentos = new Equip();
                equipamentos.setCodEquip(Integer.parseInt(codequip));
                equipamentos.setNome(nome);
                equipamentos.setMarca(marca);
                equipamentos.setDtfabr(dtfabr);


                long id = EquipDao.getInstance(context).insert(equipamentos);
                if(id > 0){
                    return "Equipamento cadastrado com sucesso!";
                }else{
                    return "Não foi possível gravar os dados do equipamento." +
                            " Solicite suporte técnico.";
                }
            }


        }catch (Exception ex){
            Log.e("Unipar",
                    "Erro salvarEquipamento(): "+ex.getMessage());
        }
        return "Erro ao gravar dados do Equipamento. " +
                "Solicite suporte técnico.";
    }

    public ArrayList<Equip> retornarTodosEquipamentos(){return EquipDao.getInstance(context).getAll();
    }







}
