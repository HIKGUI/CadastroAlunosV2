package com.example.cadastroalunos.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cadastroalunos.R;
import com.example.cadastroalunos.dao.EquipDao;
import com.example.cadastroalunos.model.Equip;


import java.util.ArrayList;

public class EquipListAdapter extends
        RecyclerView.Adapter<EquipListAdapter.ViewHolder> {

    private ArrayList<Equip> listaEquipamentos;
    private Context context;


    public EquipListAdapter(ArrayList<Equip> listaEquipamentos,
                            Context context) {
        this.listaEquipamentos = listaEquipamentos;
        this.context = context;

    }

    /**
     * Método responsável em carregar o
     * arquivo xml para cada elemento da lista
     * @return
     */
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater =
                LayoutInflater.from(parent.getContext());

        View listItem =
                inflater.inflate(R.layout.item_list_equip,
                        parent, false);

        return new ViewHolder(listItem);



    }

    /**
     * Método responsável em escrever os dados no layout
     */
    private EquipDao equipDao;

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Equip Equipamentos = listaEquipamentos.get(position);
        holder.tvCodEquip.setText(String.valueOf(Equipamentos.getCodEquip()));
        holder.tvNome.setText(String.valueOf(Equipamentos.getNome()));
        holder.tvMarca.setText(Equipamentos.getMarca());
        holder.tvDtFabr.setText(Equipamentos.getDtfabr());
        holder.tvEstado.setText(Equipamentos.getEstado());

        holder.BtAtualizar.setOnClickListener(v -> {



            int codEquip = Equipamentos.getCodEquip();
            String novoEstado = Equipamentos.getEstado();

            if(novoEstado == "S"){
                 novoEstado = "N";
            }else {
                 novoEstado = "S";
            }



            // Atualiza o estado no banco de dados usando o DAO
            EquipDao dao = EquipDao.getInstance(context);
            long resultado = dao.updateEstado(codEquip, novoEstado);

            if (resultado > 0) {
                // Atualiza o estado na interface
                Equipamentos.setEstado(novoEstado);
                holder.tvEstado.setText(novoEstado);

                // Exibe uma mensagem de sucesso
                Toast.makeText(context, "Estado atualizado ", Toast.LENGTH_SHORT).show();
            } else {
                // Exibe uma mensagem de erro
                Toast.makeText(context, "Erro ao atualizar estado", Toast.LENGTH_SHORT).show();
            }


        });



    }


    @Override
    public int getItemCount() {
        return listaEquipamentos.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView tvCodEquip, tvNome, tvMarca, tvDtFabr, tvEstado;
        public EditText edCpfLog;
        public Button BtAtualizar;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            this.tvCodEquip = itemView.findViewById(R.id.tvCodEquip);
            this.tvNome = itemView.findViewById(R.id.tvNome);
            this.tvMarca = itemView.findViewById(R.id.tvMarca);
            this.tvDtFabr = itemView.findViewById(R.id.tvDtFabr);
            this.tvEstado = itemView.findViewById(R.id.tvEstado);
            this.BtAtualizar = itemView.findViewById(R.id.BtAtualizar);
            this.edCpfLog = itemView.findViewById(R.id.edCpfLog);

        }
    }






}
