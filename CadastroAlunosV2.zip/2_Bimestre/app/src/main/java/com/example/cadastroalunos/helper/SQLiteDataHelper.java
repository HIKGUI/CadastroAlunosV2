package com.example.cadastroalunos.helper;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;



public class SQLiteDataHelper extends SQLiteOpenHelper {


    public SQLiteDataHelper(Context context) {
        super(context, "ALUGUEL_EQUIP.db", null, 5);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL(
                "CREATE TABLE EQUIPAMENTOS (COD_EQUIP INTEGER, NOME VARCHAR(100), MARCA VARCHAR(50), DTFABR VARCHAR(10), ESTADO VARCHAR(2), CPFFK INT )");


    }



    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS EQUIPAMENTOS");
        onCreate(sqLiteDatabase);
    }





}
