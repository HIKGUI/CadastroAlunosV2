package com.example.cadastroalunos.helper;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SQLiteDataHelper2 extends SQLiteOpenHelper {


    public SQLiteDataHelper2(Context context) {
        super(context, "cadastro_usuario.db", null, 2);
    }

    private static final String TABLE_NAME = "USUARIO";
    private static final String COL_CPF = "CPF";
    private static final String COL_SENHA = "SENHA";


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(
                "CREATE TABLE USUARIO (CPF INTEGER, US_NOME VARCHAR(100), DATANASC VARCHAR(10), SENHA VARCHAR(50))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS USUARIO");
        onCreate(sqLiteDatabase);
    }

    // Método para verificar login
    public boolean checkUser(String cpf, String senha) {
        SQLiteDatabase basedados = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + COL_CPF + " = ? AND " + COL_SENHA + " = ?";
        Cursor cursor = basedados.rawQuery(query, new String[]{cpf, senha});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }








}















