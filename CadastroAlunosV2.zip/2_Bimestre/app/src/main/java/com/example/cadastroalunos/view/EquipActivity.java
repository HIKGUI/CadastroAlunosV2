package com.example.cadastroalunos.view;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.cadastroalunos.dao.EquipDao;


import com.example.cadastroalunos.R;
import com.example.cadastroalunos.adapter.EquipListAdapter;
import com.example.cadastroalunos.controller.EquipController;
import com.example.cadastroalunos.model.Equip;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class EquipActivity extends AppCompatActivity {


    private FloatingActionButton btAddEquipamentos;
    private RecyclerView rvEquipamentos;
    private EquipController controller;
    private AlertDialog dialog;
    private View viewCadastro;
    private EditText edCodEquip, edNome, edMarca, edDtFabr,edCpfLog;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_equip);


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        controller = new EquipController(this);
        rvEquipamentos = findViewById(R.id.rvEquipamentos);
        btAddEquipamentos = findViewById(R.id.btAddEquipamentos);
        btAddEquipamentos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirCadastro();
            }
        });

        atualizarListaEquipamentos();








    }




    private void atualizarListaEquipamentos(){
        ArrayList<Equip> listaEquipametnos =
                controller.retornarTodosEquipamentos();

        EquipListAdapter adapter =
                new EquipListAdapter(listaEquipametnos, this);

        rvEquipamentos.setLayoutManager(new LinearLayoutManager(this));
        rvEquipamentos.setAdapter(adapter);
    }

    private void abrirCadastro(){
        //Carregar o xml do layout do cadastro
        viewCadastro = getLayoutInflater()
                .inflate(R.layout.dialog_cadastro_equip, null);

        edCodEquip = viewCadastro.findViewById(R.id.edCodEquip);
        edNome = viewCadastro.findViewById(R.id.edNome);
        edMarca = viewCadastro.findViewById(R.id.edMarca);
        edDtFabr = viewCadastro.findViewById(R.id.edDtFabr);
        edCpfLog = viewCadastro.findViewById(R.id.edCpfLog);



        //Carregando o popup
        final AlertDialog.Builder builder =
                new AlertDialog.Builder(this);

        builder.setTitle("CADASTRO DE EQUIPAMENTO"); //setando o titulo da tela
        builder.setView(viewCadastro); //setando o layout carregado
        builder.setCancelable(false);//não deixa o popup fechar ao clicar fora

        //Adicionando o botão cancelar, que fechará o dialog
        builder.setNegativeButton("CANCELAR", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialog.dismiss();
            }
        });

        //Adicionando o botão salvar
        //nesse ponto nào vamos adicionar o método
        //onclick, pois é necessário que os EditTexts
        // da tela estejam criados, e nesse momento
        //não estão criados
        builder.setPositiveButton("SALVAR", null);

        //Cria o dialog com o layout e os campos carrgados
        dialog = builder.create();

        //Após carregar o dialog precisamos adicionar
        // o método onClickListener no no botão SALVAR
        // agora os EditTexts estão criados em memória
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                Button bt = dialog.getButton(DialogInterface.BUTTON_POSITIVE);
                bt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        salvarDados();
                    }
                });
            }
        });

        //Exibe o dialog na tela
        dialog.show();

    }

    private void salvarDados(){
        //Envia os dados de CODIGO DO EQUIPAMENTO, nome, MARCA, DATA FABR
        //para gravar o EQUIP, validando
        //os campos e se existe o EQUIP cadastrado
        String retorno = controller
                .salvarEquipamento(edCodEquip.getText().toString(),
                        edNome.getText().toString(),
                        edMarca.getText().toString(),
                        edDtFabr.getText().toString());

        //Informa o erro caso no campo CODIGO EQUIP
        // tenha problema
        //com o CODIGO DO EQUIPAMENTO
        if(retorno.contains("CODEQUIP")){
            edCodEquip.setError(retorno);
            edCodEquip.requestFocus();
            return;
        }

        //Informa o erro no campo Nome
        // caso tenha algum problema com
        //nome do Equipamento
        if(retorno.contains("NOME")){
            edNome.setError(retorno);
            edNome.requestFocus();
            return;
        }

        //Informa o erro no campo Nome
        // caso tenha algum problema com
        //marca do equipamento
        if(retorno.contains("MARCA")){
            edMarca.setError(retorno);
            edMarca.requestFocus();
            return;
        }

        //Informa o erro no campo Nome
        // caso tenha algum problema com
        //data fabricação do equipamento
        if(retorno.contains("DTFABR")){
            edDtFabr.setError(retorno);
            edDtFabr.requestFocus();
            return;
        }


        //Ao gravar o equipamento atualiza a lista
        //e fecha o dialog
        if(retorno.contains("sucesso")){
            atualizarListaEquipamentos();
            dialog.dismiss();
        }

        //Exibe mensagem
        Toast.makeText(this,
                retorno,
                Toast.LENGTH_LONG).show();
    }










}