package com.example.cadastroalunos.model;

public class Usuario {
    private int cpf;

    private String nomeus;

    private String datanasc;

    private String senha;

    public Usuario() {
    }

    public int getCpf() {return cpf;}

    public void setCpf(int cpf) {

        this.cpf = cpf;
    }


    public String getNomeus() {
        return nomeus;
    }

    public void setNomeus(String nomeus) {
        this.nomeus = nomeus;
    }


    public String getDatanasc() {
        return datanasc;
    }

    public void setDatanasc(String datanasc) {
        this.datanasc = datanasc;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}
