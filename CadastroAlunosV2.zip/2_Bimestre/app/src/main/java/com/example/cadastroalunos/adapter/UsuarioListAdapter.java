package com.example.cadastroalunos.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cadastroalunos.R;
import com.example.cadastroalunos.model.Usuario;

import java.util.ArrayList;

public class UsuarioListAdapter extends
        RecyclerView.Adapter<UsuarioListAdapter.ViewHolder> {

    private ArrayList<Usuario> listaUsuarios;
    private Context context;

    public UsuarioListAdapter(ArrayList<Usuario> listaUsuarios,
                              Context context) {
        this.listaUsuarios = listaUsuarios;
        this.context = context;
    }

    /**
     * Método responsável em carregar o
     * arquivo xml para cada elemento da lista
     * @return
     */
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater =
                LayoutInflater.from(parent.getContext());

        View listItem =
                inflater.inflate(R.layout.item_list_usuario,
                        parent, false);

        return new ViewHolder(listItem);
    }

    /**
     * Método responsável em escrever os dados no layout
     */
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Usuario usuarios = listaUsuarios.get(position);
        holder.tvCpf.setText(String.valueOf(usuarios.getCpf()));
        holder.tvNomeUs.setText(String.valueOf(usuarios.getNomeus()));
        holder.tvDataNasc.setText(usuarios.getDatanasc());
        holder.tvSenha.setText(usuarios.getSenha());
    }

    @Override
    public int getItemCount() {
        return listaUsuarios.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView tvCpf, tvNomeUs, tvDataNasc, tvSenha;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            this.tvCpf = itemView.findViewById(R.id.tvCpf);
            this.tvNomeUs = itemView.findViewById(R.id.tvNomeUs);
            this.tvDataNasc = itemView.findViewById(R.id.tvDataNasc);
            this.tvSenha = itemView.findViewById(R.id.tvSenha);
        }
    }
}
