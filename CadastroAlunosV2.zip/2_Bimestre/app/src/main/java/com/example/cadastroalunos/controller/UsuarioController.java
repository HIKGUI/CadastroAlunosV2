package com.example.cadastroalunos.controller;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.example.cadastroalunos.dao.UsuarioDao;
import com.example.cadastroalunos.model.Usuario;

import java.util.ArrayList;

public class UsuarioController {

    private Context context;

    public UsuarioController(Context context) {
        this.context = context;
    }

    public String salvarUsuarios(String cpf, String nomeus, String datanasc, String senha){
        try{
            if(TextUtils.isEmpty(cpf)){
                return "Informe o CPF";
            }
            if(TextUtils.isEmpty(nomeus)){
                return "Informe o NOME ";
            }
            if(TextUtils.isEmpty(datanasc)){
                return "Informe a DATA DE NASCIMENTO";
            }
            if(TextUtils.isEmpty(senha)){
                return "Informe a SENHA";
            }

            //Verifica se existe um equipamento cadastrado com
            // o COD EQUIPO informado
            Usuario usuarios = UsuarioDao
                    .getInstance(context)
                    .getById(Integer.parseInt(cpf));

            if(usuarios != null){
                return "O Codiogo do Equipamento ("+cpf+") já está cadastrado.";
            }else{
                usuarios = new Usuario();
                usuarios.setCpf(Integer.parseInt(cpf));
                usuarios.setNomeus(nomeus);
                usuarios.setDatanasc(datanasc);
                usuarios.setSenha(senha);

                long id = UsuarioDao.getInstance(context).insert(usuarios);
                if(id > 0){
                    return "Usuario cadastrado com sucesso!";
                }else{
                    return "Não foi possível gravar os dados do equipamento." +
                            " Solicite suporte técnico.";
                }
            }


        }catch (Exception ex){
            Log.e("Unipar",
                    "Erro salvarEquipamento(): "+ex.getMessage());
        }
        return "Erro ao gravar dados do Equipamento. " +
                "Solicite suporte técnico.";
    }

    public ArrayList<Usuario> retornarTodosUsuarios(){return UsuarioDao.getInstance(context).getAll();
    }

}
