package com.example.cadastroalunos.view;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.cadastroalunos.R;
import com.example.cadastroalunos.helper.SQLiteDataHelper2;


public class LoginActivity extends AppCompatActivity {

    private SQLiteDataHelper2 basedados;

    //Contexto

    private EditText edCpfLog, edPassword;
    private Button btAcessar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        edCpfLog = findViewById(R.id.edCpfLog);
        edPassword = findViewById(R.id.edPassword);
        btAcessar = findViewById(R.id.btAcessar);


        //Abrir a conexão com a base de dados usando o construtor simplificado
        basedados = new SQLiteDataHelper2(this);



        btAcessar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cpflogin = edCpfLog.getText().toString().trim();
                String password = edPassword.getText().toString().trim();

                if (cpflogin.isEmpty() || password.isEmpty()) {
                    // Verificar campos vazios
                    Toast.makeText(LoginActivity.this, "Por favor, preencha todos os campos.", Toast.LENGTH_SHORT).show();
                } else {
                    // Verificar login no banco de dados
                    if (basedados.checkUser(cpflogin, password)) {
                        Toast.makeText(LoginActivity.this, "Login bem-sucedido!", Toast.LENGTH_SHORT).show();
                        // Adicionar ação para redirecionar o usuário ou abrir uma nova pagina

                        Intent intent =
                                new Intent(LoginActivity.this,
                                        EquipActivity.class);


                        startActivity(intent);

                    } else {
                        Toast.makeText(LoginActivity.this, "CPF ou senha inválidos.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });






    }
















}