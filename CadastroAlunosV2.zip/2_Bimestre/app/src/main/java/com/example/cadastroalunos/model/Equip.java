package com.example.cadastroalunos.model;

public class Equip {
    private int codequip;
    private String nome;

    private String marca;

    private String dtfabr;

    private String estado;

    private int cpffk;

    public Equip() {
    }

    public int getCodEquip() {return codequip;}

    public void setCodEquip(int codequip) {
        this.codequip = codequip;
    }

    public String getNome() {return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getDtfabr() {
        return dtfabr;
    }

    public void setDtfabr(String dtfabr) {
        this.dtfabr = dtfabr;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getCpffk() {return cpffk;}

    public void setCpffk(int cpffk) {
        this.cpffk = cpffk;
    }


}
