package com.example.cadastroalunos.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.cadastroalunos.helper.SQLiteDataHelper2;
import com.example.cadastroalunos.model.Usuario;

import java.util.ArrayList;

public class UsuarioDao implements IGenericDao<Usuario>{

    //Variável responsável por abri a conexão com a BD
    private SQLiteOpenHelper openHelper;

    //Base de Dados
    private SQLiteDatabase baseDados;

    //nome das colunas da tabela
    private String[]colunas = {"CPF","US_NOME", "DATANASC", "SENHA"};

    //Nome da tabela
    private String tabela = "USUARIO";

    //Contexto
    private Context context;

    private static UsuarioDao instancia;

    public static UsuarioDao getInstance(Context context){
        if(instancia == null) {
            instancia = new UsuarioDao(context);
        }
        return instancia;
    }

    private UsuarioDao(Context context) {
        this.context = context;

        // Abrir a conexão com a base de dados usando o construtor simplificado
        openHelper = new SQLiteDataHelper2(this.context);
        baseDados = openHelper.getWritableDatabase();

    }

    /**
     * Método para inserir dados na tabela Equipamento
     * @param obj Equipamento
     * @return a linha que foi inserido o registro
     */
    @Override
    public long insert(Usuario obj) {
        try{
            ContentValues valores = new ContentValues();
            valores.put(colunas[0], obj.getCpf());
            valores.put(colunas[1], obj.getNomeus());
            valores.put(colunas[2], obj.getDatanasc());
            valores.put(colunas[3], obj.getSenha());

            return baseDados.insert(tabela, null, valores);

        }catch (SQLException ex){
            Log.e("UNIPAR",
                    "ERRO: EquipamentoDao.insert() "+
                    ex.getMessage());
        }

        return 0;
    }

    /**
     * Atualizar registro na tabela Equipemento
     * @param obj Equipamento
     * @return
     */
    @Override
    public long update(Usuario obj) {
        try{
            ContentValues valores = new ContentValues();
            valores.put(colunas[1], obj.getNomeus());

            String[]identificador =
                    {String.valueOf(obj.getCpf())};

            return baseDados.update(tabela,
                    valores,
                    colunas[0]+"= ?",
                    identificador);

        }catch (SQLException ex){
            Log.e("UNIPAR",
                    "ERRO: EquipamentoDao.update() "+
                            ex.getMessage());
        }
        return 0;
    }

    @Override
    public long delete(Usuario obj) {
        try{
            String[]identificador =
                    {String.valueOf(obj.getCpf())};

            return baseDados.delete(tabela,
                    colunas[0]+" = ?",
                    identificador);

        }catch (SQLException ex){
            Log.e("UNIPAR",
                    "ERRO: EquipamentoDao.delete() "+
                            ex.getMessage());
        }
        return 0;
    }

    @Override
    public ArrayList<Usuario> getAll() {
        ArrayList lista = new ArrayList<>();
        try{
            //SELECT * FROM ALUNO
            Cursor cursor = baseDados.query(tabela,
                    colunas, null, null,
                    null, null, colunas[0]);

            while(cursor.moveToNext()){
                Usuario usuarios = new Usuario();
                usuarios.setCpf(cursor.getInt(0));
                usuarios.setNomeus(cursor.getString(1));
                usuarios.setDatanasc(cursor.getString(2));
                usuarios.setSenha(cursor.getString(3));

                lista.add(usuarios);
            }

            cursor.close();
            return lista;

        }catch (SQLException ex){
            Log.e("UNIPAR",
                    "ERRO: EquipDao.getAll() "+
                            ex.getMessage());
        }

        return null;
    }

    @Override
    public Usuario getById(int id) {
        try{
            String[]identificador =
                    {String.valueOf(id)};

            Cursor cursor = baseDados.query(tabela,
                    colunas, colunas[0]+" = ?",
                    identificador,
                    null, null, null);

            if(cursor.moveToFirst()){
                Usuario usuarios = new Usuario();
                usuarios.setCpf(cursor.getInt(0));
                usuarios.setNomeus(cursor.getString(1));
                usuarios.setDatanasc(cursor.getString(2));
                usuarios.setSenha(cursor.getString(3));

                cursor.close();
                return usuarios;
            }
        }catch (SQLException ex){
            Log.e("UNIPAR",
                    "ERRO: EquipDao.getById() "+
                            ex.getMessage());
        }
        return null;
    }
}
